package io.github.mohamtur1.fourcbon2

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.io.IOException

/**
 * Division 11: Durable local persistence engine supporting structured entity namespaces,
 * restart recovery, and deterministic ordering across both Android SQLite and disk-backed
 * JVM unit tests.
 */
data class StoredEntityRow(
    val namespace: String,
    val id: String,
    val payloadJson: String,
    val updatedAtEpochMs: Long,
)

interface LocalStoreBackend {
    fun upsert(namespace: String, id: String, payloadJson: String, updatedAtEpochMs: Long)
    fun get(namespace: String, id: String): StoredEntityRow?
    fun listByNamespace(namespace: String): List<StoredEntityRow>
    fun delete(namespace: String, id: String): Boolean
    fun clearNamespace(namespace: String)
}

/**
 * Production Android SQLite backend storing versioned JSON entity rows in an indexed table.
 */
class AndroidSqliteBackend(context: Context) : LocalStoreBackend {
    private val helper = DbHelper(context.applicationContext)

    override fun upsert(namespace: String, id: String, payloadJson: String, updatedAtEpochMs: Long) {
        validateKey(namespace, "namespace")
        validateKey(id, "id")
        val db = helper.writableDatabase
        val values = ContentValues().apply {
            put(COL_NAMESPACE, namespace)
            put(COL_ID, id)
            put(COL_PAYLOAD, payloadJson)
            put(COL_UPDATED_AT, updatedAtEpochMs)
        }
        db.insertWithOnConflict(TABLE_ENTITIES, null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    override fun get(namespace: String, id: String): StoredEntityRow? {
        val db = helper.readableDatabase
        db.query(
            TABLE_ENTITIES,
            arrayOf(COL_NAMESPACE, COL_ID, COL_PAYLOAD, COL_UPDATED_AT),
            "$COL_NAMESPACE = ? AND $COL_ID = ?",
            arrayOf(namespace, id),
            null,
            null,
            null,
        ).use { cursor ->
            if (!cursor.moveToFirst()) return null
            return StoredEntityRow(
                namespace = cursor.getString(0),
                id = cursor.getString(1),
                payloadJson = cursor.getString(2),
                updatedAtEpochMs = cursor.getLong(3),
            )
        }
    }

    override fun listByNamespace(namespace: String): List<StoredEntityRow> {
        val db = helper.readableDatabase
        val out = ArrayList<StoredEntityRow>()
        db.query(
            TABLE_ENTITIES,
            arrayOf(COL_NAMESPACE, COL_ID, COL_PAYLOAD, COL_UPDATED_AT),
            "$COL_NAMESPACE = ?",
            arrayOf(namespace),
            null,
            null,
            "$COL_UPDATED_AT DESC, $COL_ID ASC",
        ).use { cursor ->
            while (cursor.moveToNext()) {
                out.add(
                    StoredEntityRow(
                        namespace = cursor.getString(0),
                        id = cursor.getString(1),
                        payloadJson = cursor.getString(2),
                        updatedAtEpochMs = cursor.getLong(3),
                    ),
                )
            }
        }
        return out
    }

    override fun delete(namespace: String, id: String): Boolean {
        val db = helper.writableDatabase
        return db.delete(
            TABLE_ENTITIES,
            "$COL_NAMESPACE = ? AND $COL_ID = ?",
            arrayOf(namespace, id),
        ) > 0
    }

    override fun clearNamespace(namespace: String) {
        val db = helper.writableDatabase
        db.delete(TABLE_ENTITIES, "$COL_NAMESPACE = ?", arrayOf(namespace))
    }

    private class DbHelper(context: Context) :
        SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
        override fun onConfigure(db: SQLiteDatabase) {
            super.onConfigure(db)
            db.enableWriteAheadLogging()
        }

        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                """
                CREATE TABLE $TABLE_ENTITIES (
                    $COL_NAMESPACE TEXT NOT NULL,
                    $COL_ID TEXT NOT NULL,
                    $COL_PAYLOAD TEXT NOT NULL,
                    $COL_UPDATED_AT INTEGER NOT NULL,
                    PRIMARY KEY ($COL_NAMESPACE, $COL_ID)
                )
                """.trimIndent(),
            )
            db.execSQL(
                """
                CREATE INDEX idx_${TABLE_ENTITIES}_ns_updated
                ON $TABLE_ENTITIES ($COL_NAMESPACE, $COL_UPDATED_AT DESC)
                """.trimIndent(),
            )
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            // Schema v1 baseline; future migrations preserve existing rows.
        }
    }

    private companion object {
        const val DB_NAME = "4cbon2_local_workspace.db"
        const val DB_VERSION = 1
        const val TABLE_ENTITIES = "entity_records"
        const val COL_NAMESPACE = "namespace"
        const val COL_ID = "entity_id"
        const val COL_PAYLOAD = "payload_json"
        const val COL_UPDATED_AT = "updated_at_ms"
    }
}

/**
 * Atomic disk-directory store backend that persists each namespace as a structured JSON file.
 * Enables true disk-persistence and process-restart verification in JVM unit tests and serves
 * as a portable fallback when Android SQLite native libraries are absent.
 */
class DiskDirectoryBackend(private val rootDirectory: File) : LocalStoreBackend {
    private val lock = Any()

    init {
        if (!rootDirectory.exists() && !rootDirectory.mkdirs()) {
            throw IOException("Could not create local database directory: $rootDirectory")
        }
    }

    override fun upsert(namespace: String, id: String, payloadJson: String, updatedAtEpochMs: Long) {
        validateKey(namespace, "namespace")
        validateKey(id, "id")
        synchronized(lock) {
            val map = readNamespaceMapLocked(namespace)
            map[id] = StoredEntityRow(namespace, id, payloadJson, updatedAtEpochMs)
            writeNamespaceMapLocked(namespace, map)
        }
    }

    override fun get(namespace: String, id: String): StoredEntityRow? = synchronized(lock) {
        readNamespaceMapLocked(namespace)[id]
    }

    override fun listByNamespace(namespace: String): List<StoredEntityRow> = synchronized(lock) {
        readNamespaceMapLocked(namespace)
            .values
            .sortedWith(compareByDescending<StoredEntityRow> { it.updatedAtEpochMs }.thenBy { it.id })
    }

    override fun delete(namespace: String, id: String): Boolean = synchronized(lock) {
        val map = readNamespaceMapLocked(namespace)
        val removed = map.remove(id) != null
        if (removed) {
            writeNamespaceMapLocked(namespace, map)
        }
        removed
    }

    override fun clearNamespace(namespace: String) = synchronized(lock) {
        val file = namespaceFile(namespace)
        if (file.exists()) {
            file.delete()
        }
    }

    private fun namespaceFile(namespace: String): File {
        val safeName = namespace.replace(Regex("[^A-Za-z0-9_.-]"), "_")
        return File(rootDirectory, "$safeName.table.json")
    }

    private fun readNamespaceMapLocked(namespace: String): LinkedHashMap<String, StoredEntityRow> {
        val file = namespaceFile(namespace)
        val result = LinkedHashMap<String, StoredEntityRow>()
        if (!file.exists()) return result
        val text = try {
            file.readText(Charsets.UTF_8)
        } catch (_: IOException) {
            return result
        }
        if (text.isBlank()) return result
        val root = try {
            JsonCodec.parseObject(text)
        } catch (_: JsonParseException) {
            // Corrupt table file does not crash startup; callers observe an empty/recoverable state.
            return result
        }
        for (item in root.array("rows")) {
            val obj = item as? JsonValue.Obj ?: continue
            val id = obj.string("id") ?: continue
            val payload = obj.string("payloadJson") ?: continue
            val updatedAt = obj.long("updatedAtEpochMs", 0L)
            result[id] = StoredEntityRow(namespace, id, payload, updatedAt)
        }
        return result
    }

    private fun writeNamespaceMapLocked(namespace: String, rows: Map<String, StoredEntityRow>) {
        val file = namespaceFile(namespace)
        val tempFile = File(rootDirectory, "${file.name}.tmp")
        val json = JsonCodec.stringify(
            JsonValue.Obj(
                mapOf(
                    "schemaVersion" to JsonValue.Num(1.0, "1"),
                    "namespace" to JsonValue.Str(namespace),
                    "rows" to JsonValue.Arr(
                        rows.values.map { row ->
                            JsonValue.Obj(
                                mapOf(
                                    "id" to JsonValue.Str(row.id),
                                    "payloadJson" to JsonValue.Str(row.payloadJson),
                                    "updatedAtEpochMs" to JsonValue.Num(
                                        row.updatedAtEpochMs.toDouble(),
                                        row.updatedAtEpochMs.toString(),
                                    ),
                                ),
                            )
                        },
                    ),
                ),
            ),
        )
        tempFile.writeText(json, Charsets.UTF_8)
        if (!tempFile.renameTo(file)) {
            file.writeText(json, Charsets.UTF_8)
            tempFile.delete()
        }
    }
}

/**
 * Shared application database facade backed by [LocalStoreBackend].
 */
class FourCBOn2Database(val backend: LocalStoreBackend) {
    fun putSetting(key: String, value: String, nowEpochMs: Long = System.currentTimeMillis()) {
        val payload = JsonCodec.stringify(JsonValue.Obj(mapOf("value" to JsonValue.Str(value))))
        backend.upsert(NS_SETTINGS, key, payload, nowEpochMs)
    }

    fun getSetting(key: String): String? {
        val row = backend.get(NS_SETTINGS, key) ?: return null
        return try {
            JsonCodec.parseObject(row.payloadJson).string("value")
        } catch (_: JsonParseException) {
            null
        }
    }

    companion object {
        const val NS_SETTINGS = "app_settings"
        const val NS_AGENT_DRAFTS = "agent_drafts"
        const val NS_WORKSPACE_FILES = "workspace_files"
        const val NS_KNOWLEDGE_LIBRARY = "knowledge_library"
        const val NS_WAITING_QUEUE = "waiting_queue"
    }
}

private fun validateKey(value: String, label: String) {
    require(value.isNotBlank() && value.length <= 128) { "Invalid $label: must be 1..128 non-blank chars." }
}
