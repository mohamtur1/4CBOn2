# 4CBOn2 — Timeboxed Build Plan

**Build in progress · Revised 23 October 2026 · Divisions 01–08 completed, Division 09 authorization-blocked, and Division 10 checkpointed pending Android toolchain restoration; public GitHub read is verified, Kaggle public read requires authorization, the fixed Colab notebook target is currently missing, and no updated retained APK, notebook, account connection, credential entry, or phone/device test exists yet**

## Decision

Use **42 small build divisions for the expanded first prototype**. This retains the earlier Android/notebook work and adds twelve phone-control work packages. The divisions below are renumbered in dependency order and supersede the earlier 30-division numbering.

The product supports selected, authorized app actions—not universal access to every app. Follow `4CBOn2_Phone_Control_Design_v4.md` for the distribution, device, permission, and takeover gates. The notebook target remains `4CBOn2_Kaggle6.ipynb` in `mohamtur1/4CBOn2`.

Every division is a **maximum 30-minute work session, including waiting, verification, and saving progress**. This is a session limit, not a guarantee that a dependency download, account approval, first compile, complete feature, or device test finishes in 30 minutes.

If unfinished, stop safely, checkpoint the exact state, and create a small continuation, such as 10a/10b. Do not run longer or label incomplete/unverified work complete. Forty-two divisions are an initial decomposition; discoveries can require additional timeboxed subdivisions. This is not a promise to complete universal phone control in 21 hours.

## Session contract

- Up to **20 minutes** implementation, investigation, or necessary waiting.
- Up to **7 minutes** targeted verification.
- Reserve **3 minutes** for a recoverable checkpoint and progress report.
- Finish earlier when the narrow target is verified.
- Do not start a long operation near the cap. Bound/cancel local work when safe; record an already accepted remote job as pending instead of waiting indefinitely or repeating it.
- Retain the last verified version. Extend the same application incrementally, one division at a time.
- Owner permission for real external effects remains a separate gate. No credentials in source code, logs, or design documents.

## The 42 build divisions

| No. | Division | Narrow deliverable / verification target |
| --- | --- | --- |
| 01 | Freeze expanded prototype scope | Record supported profiles, distribution assumptions, exclusions, dependencies, and acceptance checks |
| 02 | Phone-control feasibility and policy gate | Review deployment/device prerequisites; record unverified phone capabilities and prohibit policy/security workarounds |
| 03 | Prepare Android build tools | Inventory Java/SDK/build tooling, pin compatible versions, and record missing downloads or blockers |
| 04 | Create minimal Android project | A Kotlin/Compose project with a compilable entry screen |
| 05 | Produce first debug APK | Development build/signing result, artifact path, and checksum; installation/device verification recorded separately |
| 06 | Add navigation | Home, Ask, Agents, Browser, Activity; disabled/unimplemented features labeled |
| 07 | Protected credential storage | Secure native settings and credential boundary; no embedded tokens or sensitive logs |
| 08 | Prove GitHub read access | Authorized repository read or an honest account/network blocker |
| 09 | Prove Kaggle read access | Permitted account/API read; distinguish missing authorization from unsupported operations |
| 10 | Prove Colab entry/control route | Notebook opening plus supported control-path investigation; manual-only versus actual API capability recorded |
| 11 | Local database | Initial entities and persistence/restart test |
| 12 | Selected-app capability registry | Owner-selected app identities, narrow discovery, action-level support, and unavailable states; no blanket inventory collection |
| 13 | On-device scope contract | App/account/data/action/expiry limits; deny unselected targets and unauthorized cloud transfer |
| 14 | Takeover and cancellation lease | Local Take Over/Stop state; reject stale commands and require explicit resume |
| 15 | Offline agent drafts | Save/edit/load goal, template, job profile, caps, and draft state |
| 16 | Safe file import/export | User-selected documents and workspace export without broad phone filesystem access |
| 17 | Offline knowledge library | Read/search saved reports and evidence with provenance and update times |
| 18 | Small local analysis | One bounded CSV/JSON routine with valid/invalid fixtures |
| 19 | Persistent waiting queue | Save jobs, recover after restart, defer network tasks; no automatic consequential replay |
| 20 | Sensitive-action approval gate | Scoped destination/artifact identity, expiry, caps, and confirmation tests |
| 21 | One harmless app intent/API action | A supported open/prepare action with actual result/handoff semantics; no unrestricted UI input |
| 22 | GitHub cache and diff | Refresh a permitted version, show local diff, and prepare an exportable change; no unapproved write/force-push |
| 23 | Kaggle metadata/status | Supported competition/job views with real last-sync and stale/error states |
| 24 | Chrome-backed opening | Custom Tab/service links and browser fallback; no unrestricted Chrome-control claim |
| 25 | Controlled browser workspace | One reviewed public-page/reader workflow, URL boundaries, no privileged native bridge to untrusted content |
| 26 | Consented observation boundary | Shared/structured data first; any screen capture separately gated, secure/sensitive contexts excluded, cloud upload Off by default |
| 27 | Actual action timeline | Record plan/action/result/check events; distinguish attempted, pending, manual, verified, and uncertain outcomes |
| 28 | Shared job bundle | Versioned app/notebook contract, manifest, private export/import, hashes, and policy revalidation; a hash is not authority |
| 29 | Notebook skeleton | Exact file `4CBOn2_Kaggle6.ipynb`, runtime detection, controller/runner roles, capability panel |
| 30 | Colab built-in AI adapter | Real service/model probe and bounded request; no provider fallback or proxy-credential export |
| 31 | One bounded agent loop | One supported goal -> permitted action -> verification workflow; stop/error path demonstrated |
| 32 | Critical phone-action guard | Sensitive/manual-only contexts, exact action preview, account checks, protected-screen handoff, and no blind irreversible retry |
| 33 | Human-defined routine engine | Fixed script, explicit human trigger, known preconditions, and bounded execution; not an exemption for AI-driven Accessibility use |
| 34 | Conditional personal-lab UI runner | Only a permitted, authorized experimental configuration against an owner-controlled fixture app; unavailable if eligibility fails; not Play-compliance proof |
| 35 | Privacy and prompt-injection tests | Malicious page/message, unauthorized destination, secret/screen-content leakage, and data-sharing scope fixtures |
| 36 | Online/offline phone-control routing | Available local/API/model routes only; no fake cloud planning, locked-device bypass, or silent alternate provider |
| 37 | Kaggle prepare-only pipeline | One trusted tabular template, explicit validation, artifact checks, reproducible result |
| 38 | Submission gate and receipt states | Limits, durable intent, acknowledgment/uncertainty handling, mocked tests; live submission separately authorized |
| 39 | Minimal Improvement Lab | One baseline/candidate report, preserved versions, fixed evaluator, approval before promotion |
| 40 | Harmless cross-app integration test | A few selected supported workflows with synthetic data; scope escape, takeover, and manual handoff tested |
| 41 | Focused recovery/safety smoke tests | Offline/reconnect, stale cloud response, interrupted work, revoked permission, ambiguous acknowledgment, and duplicate-action fixtures |
| 42 | Package prototype and support matrix | Rebuild eligible debug artifact(s) and notebook bundle; checksums, instructions, actual test results, blocked capabilities, and distribution limitations |

## Current build status

| Division | Work status | Verification | Checkpoint |
| --- | --- | --- | --- |
| 01 — Freeze expanded prototype scope | **Finished** | Static design/consistency check | `android/PROTOTYPE_SCOPE.md` |
| 02 — Phone-control feasibility and policy gate | **Finished** | Static policy/architecture consistency check; no device or store test | `android/PHONE_CONTROL_FEASIBILITY.md` |
| 03 — Prepare Android build tools | **Finished** | Local inventory, compatibility baseline, and verified workspace-local provision | `android/BUILD_TOOLCHAIN.md` + `android/TOOLCHAIN_PROVISIONING.md` |
| 03a — Provision workspace-local Android toolchain | **Finished** | JDK/Gradle integrity checks; Android SDK artifact and command checks | `android/TOOLCHAIN_PROVISIONING.md` |
| 04 — Create minimal Android project | **Finished** | Wrapper, Kotlin compile, debug package, signing, and manifest checks passed in sandbox; no device test | `android/PROJECT_FOUNDATION.md` |
| 05 — Produce first debug APK | **Finished** | Clean rebuild, SHA-256, alignment, v2 debug signature, and APK manifest/package checks passed; no installation test | `android/DEBUG_APK_RELEASE.md` + `4CBOn2-debug.apk` |
| 06 — Add navigation | **Finished** | Five destinations, disabled Ask/How-do-I controls, one unit test, and sandbox build/signature checks passed; no device test | `android/NAVIGATION_FOUNDATION.md` |
| 07 — Protected credential storage | **Finished** | Keystore/AES-GCM boundary compiled; four unit tests and static/build/signature checks passed; no secret/device-keystore/live-service test | `android/CREDENTIAL_STORAGE.md` |
| 08 — Prove GitHub read access | **Finished (public route)** | HTTPS public metadata/root listing returned HTTP 200 from build environment; 9 unit/static/build/signature checks passed; no PAT, authenticated app, or device test | `android/GITHUB_READ_ACCESS.md` |
| 09 — Prove Kaggle read access | **Blocked (authorization)** | Public competition-list endpoint returned HTTP 401; read boundary, 13 unit/static/build/signature checks passed; no token/OAuth client/device test | `android/KAGGLE_READ_ACCESS.md` |
| 10 — Prove Colab entry/control route | **Finished (manual route)** | Fixed manual-handoff reference and public route investigation complete; target notebook reported missing; compile, aggregate 15-test suite, debug build, v2 signature, and static checks passed; no account/runtime/AI/device test | `android/COLAB_ENTRY_ROUTE.md` |
| 10a — Restore/verify Division 10 toolchain checkpoint | **Finished** | Toolchain restored from verified sources; compile/test/APK verification completed with bounded one-worker memory configuration | `android/COLAB_ENTRY_ROUTE.md` |
| 11–42 | **Not started** | Not tested | None |

Divisions 01–02 are foundation documentation checkpoints; Division 03/03a provisioned the active sandbox toolchain; Division 04 created and locally compiled the source skeleton; Division 05 retained and verified a debug-signed development APK; Division 06 added locally verified navigation source; Division 07 added a compiled, unpopulated credential-storage boundary; Division 08 added a read-only GitHub boundary and verified public repository visibility from the build environment; Division 09 added a read-only Kaggle boundary but correctly stopped at Kaggle’s authorization requirement; Division 10 added and locally verified a fixed manual Colab handoff reference, while the target notebook itself remains missing and runtime/AI capability remains untested. These results do **not** establish phone compatibility, authenticated GitHub/Kaggle access, a Colab account/notebook/runtime or built-in-AI call, special permissions beyond the normal Internet declaration, a real device test, store eligibility, credential entry/storage on a device, production signing, or production release readiness. The retained Division 05 APK predates the Division 06–10 source updates. No later division is implied to exist merely because it is listed.

## Dependency and blocker rules

- Division 02 is an early feasibility/policy gate, not proof that the owner device supports the desired permissions.
- Divisions 08–10 establish actual service routes or blockers. A browser-open state is not authenticated programmatic control.
- Division 30 proves built-in AI itself; runtime-management access in 10 is a different capability.
- Division 14 must work before any interactive phone input is enabled. Late remote commands must not resume a cancelled session.
- The standard profile prioritizes APIs/intents. A general-purpose autonomous Accessibility runner is not represented as Play-eligible because scope/stop controls exist.
- Division 34 stays blocked or omitted if the device/deployment is ineligible. Do not supply an OS/security bypass or mislabel the app as an accessibility tool.
- Phone UI tests initially use an owner-controlled test app and synthetic data. Do not test automation on live banking, authentication, permission-grant, or payment screens.
- Division 40 requires the applicable scope, takeover, observation, and critical-action tests. Unsupported routes remain explicit manual handoffs.
- Division 31 requires genuine supporting capabilities. A file-transfer/manual route is not a completed autonomous cloud round trip.
- Division 38 may pass mocked/local tests while live submission remains unverified; never conflate the two.
- A cloud job may outlast a session. Save its reference and check in a later session; do not wait past the cap or blindly repeat it.
- Safe offline modules can progress while unrelated remote/device gates are blocked, if their own dependencies pass.
- Division 42 is a prototype handoff, not production/security certification or Play approval.

## Progress record

Track two separate dimensions:

1. **Work status:** Not started, in progress, checkpointed, blocked, or finished.
2. **Verification:** Not tested, static check, mocked/local test, emulator test, real-device test, or live-service test.

Each division report records elapsed time, exact files/changes, actual tests/outcomes, checkpoint/artifact path, blockers, remaining work, any continuation needed, and the next eligible division.

A successful mocked or emulator test must not be labeled real-device compatible, live-service verified, or store-approved. Local checkpoints do not imply a repository commit/upload; report those only if they actually occurred through an authorized route.

## Still outside the prototype's promises

- Universal autonomous control of every installed app or website.
- Control of protected credential, payment, lock-screen, or system-consent workflows.
- Root access, hidden input, bypassed security settings, or self-granted permissions.
- A mandatory on-device LLM or full offline reasoning on an untested phone.
- An always-on backend or guaranteed Colab availability.
- A general arbitrary-code sandbox or unrestricted remote browser service.
- Every Kaggle competition type.
- Production penetration testing, Play Store approval, and production signing/distribution.

These require further legitimate, separately scoped work if applicable. They cannot be squeezed into the final division or presented as completed without evidence.

## Readiness decision

**Ready for phased foundation implementation when requested; broader phone control remains gated. Still designing now.**

The goal is one verified increment or an honest recoverable checkpoint per session—not a guaranteed entire product at 42 times 30 minutes.
