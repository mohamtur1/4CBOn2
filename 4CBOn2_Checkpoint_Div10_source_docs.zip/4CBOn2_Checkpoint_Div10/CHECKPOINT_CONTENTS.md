# 4CBOn2 Checkpoint — Division 10

This archive is a compact source-and-documents backup prepared on 23 October 2026.

Included:
- Android Kotlin/Compose source, tests, Gradle wrapper/configuration, manifest, and Android evidence documents.
- Current build plan and new-thread engineering handoff.
- Durable Markdown design documents.

Intentionally excluded:
- Android SDK/JDK/Gradle caches and generated build folders (regenerable).
- `local.properties` and any local machine path/settings.
- Credentials, tokens, cookies, browser sessions, and secrets.
- APK binaries, including the older historical debug APK, to minimize transfer size.
- DOCX copies of the design documents (the editable Markdown sources are included).

Verification at archive creation:
- No common GitHub-token pattern was found in the included source/document files.
- Latest source verification result: 15 unit tests passed, zero failures/errors/skips.
- Latest generated debug-verification APK hash (not included):
  e3250cd2c8aa86bd910e73575ce59f074618cccecf9219f5b1762e9de5169e07

Before placing this archive in any repository, inspect the contents and never add a credential.
